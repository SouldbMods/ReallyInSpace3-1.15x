# RIS3.0

DEVELOPER NOTE
You will need to go to the fabric repo to merge the jars for a forge+fabric jar

Requires Geckolib 3

GeckoLib: https://www.curseforge.com/minecraft/mc-mods/geckolib
Forge Repo

