package xyz.souldb.ris3.procedures;

import xyz.souldb.ris3.Ris3ModElements;

import java.util.Map;

@Ris3ModElements.ModElement.Tag
public class TakeOffProcedure extends Ris3ModElements.ModElement {
	public TakeOffProcedure(Ris3ModElements instance) {
		super(instance, 107);
	}

	public static void executeProcedure(Map<String, Object> dependencies) {
	}
}
